export { MafiaRoom };

const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "access-control-allow-origin": "*",
    "access-control-allow-headers": "content-type", "access-control-allow-methods": "GET,POST,OPTIONS" }
});
const shuffle = (arr) => {
  const a = [...arr];
  for (let i=a.length-1;i>0;i--) { const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; }
  return a;
};
const publicPlayer = p => ({id:p.id,name:p.name,alive:p.alive,host:p.host});
const roleName = r => ({mafia:"مافيا",doctor:"طبيب",detective:"محقق",citizen:"مواطن"}[r] || "مواطن");

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null,{headers:{
      "access-control-allow-origin":"*","access-control-allow-headers":"content-type","access-control-allow-methods":"GET,POST,OPTIONS"
    }});
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(request);
    const parts = url.pathname.split("/").filter(Boolean);
    try {
      if (parts[1] === "room" && parts[2] === "create" && request.method === "POST") {
        const body = await request.json();
        const name = String(body.name||"").trim().slice(0,24);
        if (!name) return json({error:"اكتب اسمك أولاً."},400);
        const code = Array.from(crypto.getRandomValues(new Uint8Array(4)),x=>"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[x%32]).join("");
        const id = env.MAFIA_ROOMS.idFromName(code);
        const stub = env.MAFIA_ROOMS.get(id);
        return new Response(await stub.fetch("https://room/create",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({name,code})}),{headers:{"content-type":"application/json; charset=utf-8","access-control-allow-origin":"*"}});
      }
      if (parts[1] === "room" && parts[2] === "join" && request.method === "POST") {
        const body = await request.json(); const code=String(body.code||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,8);
        if (!code) return json({error:"اكتب رمز الغرفة."},400);
        const id=env.MAFIA_ROOMS.idFromName(code);
        return env.MAFIA_ROOMS.get(id).fetch("https://room/join",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)});
      }
      if (parts[1] === "room" && parts[2] && parts[3]) {
        const code=parts[2].toUpperCase(); const id=env.MAFIA_ROOMS.idFromName(code);
        return env.MAFIA_ROOMS.get(id).fetch(new Request("https://room/"+parts.slice(3).join("/"),request));
      }
      return json({error:"المسار غير موجود."},404);
    } catch(e) { return json({error:e.message||"حدث خطأ."},500); }
  }
};

export class MafiaRoom {
  constructor(ctx, env) { this.ctx=ctx; this.env=env; }
  async fetch(request) {
    const url=new URL(request.url), path=url.pathname;
    let s=await this.ctx.storage.get("state");
    if (request.method==="POST") {
      const b=await request.json().catch(()=>({}));
      if(path==="/create") {
        if(s) return json({error:"الغرفة موجودة بالفعل."},409);
        const pid=crypto.randomUUID();
        s={code:b.code,phase:"lobby",round:0,host:pid,players:[{id:pid,name:b.name,alive:true,host:true,role:null}],night:{},votes:{},log:["تم إنشاء الغرفة. انتظر انضمام بقية اللاعبين."],result:null,investigation:null};
        await this.ctx.storage.put("state",s);
        return json({code:s.code,playerId:pid,host:true});
      }
      if(path==="/join") {
        if(!s) return json({error:"ما لقينا الغرفة. تأكد من الرمز."},404);
        const name=String(b.name||"").trim().slice(0,24);
        if(!name) return json({error:"اكتب اسمك."},400);
        if(s.phase!=="lobby") return json({error:"اللعبة بدأت بالفعل."},409);
        if(s.players.length>=6) return json({error:"الغرفة ممتلئة."},409);
        const pid=crypto.randomUUID();
        s.players.push({id:pid,name,alive:true,host:false,role:null});
        s.log.push(name+" انضم إلى الغرفة ("+s.players.length+"/6).");
        await this.ctx.storage.put("state",s);
        return json({code:s.code,playerId:pid,host:false});
      }
      const pid=String(b.playerId||"");
      const p=s?.players.find(x=>x.id===pid);
      if(!s||!p) return json({error:"تعذر العثور على اللاعب في هذه الغرفة."},401);
      if(path==="/start") {
        if(p.id!==s.host) return json({error:"مضيف الغرفة فقط يمكنه بدء اللعبة."},403);
        if(s.phase!=="lobby"||s.players.length!==6) return json({error:"تحتاج الغرفة إلى 6 لاعبين قبل البدء."},400);
        const roles=shuffle(["mafia","mafia","doctor","detective","citizen","citizen"]);
        s.players.forEach((x,i)=>{x.role=roles[i];x.alive=true;});
        s.phase="night";s.round=1;s.night={};s.votes={};s.result=null;
        s.log.push("بدأت اللعبة! حلّ الليل الأول.");
        await this.ctx.storage.put("state",s); return this.view(s,pid);
      }
      if(path==="/action") {
        if(s.phase==="finished") return json({error:"انتهت اللعبة."},400);
        if(!p.alive) return json({error:"اللاعب المقصي لا يستطيع التصويت أو تنفيذ إجراء."},400);
        const target=s.players.find(x=>x.id===String(b.targetId||""));
        if(!target||!target.alive||target.id===p.id) return json({error:"اختر لاعباً حياً آخر."},400);
        if(s.phase==="night") {
          if(p.role==="citizen") return json({error:"المواطن ينتظر الصباح."},400);
          const allowed={mafia:["mafia"],doctor:["doctor"],detective:["detective"]};
          if(!allowed[p.role]) return json({error:"لا يمكنك تنفيذ هذا الإجراء."},400);
          if(p.role==="mafia"&&target.role==="mafia") return json({error:"لا يمكنك اختيار شريكك في المافيا."},400);
          s.night[p.id]=target.id;
          const required=s.players.filter(x=>x.alive&&x.role!=="citizen").length;
          const submitted=Object.keys(s.night).filter(id=>s.players.some(x=>x.id===id&&x.alive&&x.role!=="citizen")).length;
          if(submitted>=required) this.resolveNight(s);
        } else if(s.phase==="day") {
          s.votes[p.id]=target.id;
          if(s.players.filter(x=>x.alive).every(x=>s.votes[x.id])) this.resolveVote(s);
        } else return json({error:"انتظر المرحلة التالية."},400);
        await this.ctx.storage.put("state",s); return this.view(s,pid);
      }
      if(path==="/state") return this.view(s,pid);
      return json({error:"المسار غير موجود."},404);
    }
    if(request.method==="GET" && path==="/state") {
      const pid=url.searchParams.get("playerId")||"";
      if(!s||!s.players.some(x=>x.id===pid)) return json({error:"الغرفة أو اللاعب غير موجود."},404);
      return this.view(s,pid);
    }
    return json({error:"الطلب غير مدعوم."},405);
  }
  view(s,pid) {
    const me=s.players.find(x=>x.id===pid);
    return json({code:s.code,phase:s.phase,round:s.round,host:s.host===pid,me:{id:me.id,name:me.name,role:me.role,alive:me.alive},
      players:s.players.map(x=>s.phase==="finished"?{...publicPlayer(x),role:x.role}:publicPlayer(x)),log:s.log.slice(-12),result:s.result,
      canStart:s.phase==="lobby"&&s.players.length===6&&s.host===pid,
      actionDone:s.phase==="night"?!!s.night[pid]:s.phase==="day"?!!s.votes[pid]:false,
      investigation:s.investigation&&s.investigation.viewer===pid?s.investigation.text:null,
      nightActions:Object.keys(s.night).length,votes:Object.keys(s.votes).length});
  }
  resolveNight(s) {
    const mafiaVotes={}; for (const [id,target] of Object.entries(s.night)) if(s.players.some(p=>p.id===id&&p.alive&&p.role==="mafia")) mafiaVotes[target]=(mafiaVotes[target]||0)+1;
    const mafiaChoices=Object.keys(mafiaVotes); const targetId=mafiaChoices.sort((a,b)=>mafiaVotes[b]-mafiaVotes[a])[0];
    const doctorTarget=Object.entries(s.night).find(([id])=>s.players.some(p=>p.id===id&&p.alive&&p.role==="doctor"))?.[1];
    const detectiveEntry=Object.entries(s.night).find(([id])=>s.players.some(p=>p.id===id&&p.alive&&p.role==="detective"));
    const target=s.players.find(p=>p.id===targetId);
    if(targetId && targetId!==doctorTarget && target?.alive) {
      target.alive=false;s.log.push("حلّ الصباح، وعُثر على "+target.name+" خارج اللعبة.");
    } else s.log.push("حلّ الصباح، ولم يُقصَ أحد هذه الليلة.");
    if(detectiveEntry) {
      const investigator=s.players.find(p=>p.id===detectiveEntry[0]);
      const inspected=s.players.find(p=>p.id===detectiveEntry[1]);
      s.investigation={viewer:investigator.id,text:inspected.name+(inspected.role==="mafia"?" من المافيا!":" ليس من المافيا.")};
    }
    s.night={};s.votes={};
    if(this.checkWin(s)) return;
    s.phase="day";s.log.push("مرحلة النهار: ناقشوا الأدلة ثم صوّتوا.");
  }
  resolveVote(s) {
    const tally={};for(const target of Object.values(s.votes))tally[target]=(tally[target]||0)+1;
    const max=Math.max(...Object.values(tally));const leaders=Object.keys(tally).filter(id=>tally[id]===max);
    if(leaders.length===1) {
      const out=s.players.find(p=>p.id===leaders[0]);if(out?.alive){out.alive=false;s.log.push("صوّتت الأغلبية لإقصاء "+out.name+".");}
    } else s.log.push("تعادل التصويت؛ لم يُقصَ أي لاعب.");
    s.votes={};s.night={};
    if(this.checkWin(s)) return;
    s.phase="night";s.round++;s.log.push("حلّ الليل رقم "+s.round+". أصحاب الأدوار الخاصة، اختاروا أهدافكم.");
  }
  checkWin(s) {
    const mafia=s.players.filter(p=>p.alive&&p.role==="mafia").length;
    const town=s.players.filter(p=>p.alive&&p.role!=="mafia").length;
    if(mafia===0){s.phase="finished";s.result="فاز أهل المدينة! تم كشف كل أفراد المافيا.";s.log.push(s.result);return true;}
    if(mafia>=town){s.phase="finished";s.result="فازت المافيا! أصبحت تسيطر على المدينة.";s.log.push(s.result);return true;}
    return false;
  }
}
